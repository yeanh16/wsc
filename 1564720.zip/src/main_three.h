void dostuff(int sock);
void *handle(void *param);
void error(char *msg);
int parse(const char* line);
